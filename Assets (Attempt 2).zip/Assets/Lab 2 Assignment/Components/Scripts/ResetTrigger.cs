using UnityEngine;

public class ResetTrigger : MonoBehaviour
{
    

    void Update()
    {
        
    }
}
